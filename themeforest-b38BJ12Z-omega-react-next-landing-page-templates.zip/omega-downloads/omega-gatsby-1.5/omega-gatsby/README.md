# Omega Gatsby
