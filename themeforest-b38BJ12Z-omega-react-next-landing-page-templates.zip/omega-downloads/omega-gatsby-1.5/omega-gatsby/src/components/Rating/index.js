export { default } from "./Rating";
