export { default } from "./PostCard";
