export { default } from "./InputSearch";
